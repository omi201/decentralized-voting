mod utils;

use wasm_bindgen::prelude::*;
use web_sys::console;

#[wasm_bindgen]
pub fn vote(candidate_id: u32) {
    console::log_1(&format!("Voted for candidate {}", candidate_id).into());
}

